import { Component } from '@angular/core';
import { FirstComponent } from '../first/first.component';
import { SecondComponent } from '../second/second.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-third',
  standalone: true,
  imports: [FirstComponent,SecondComponent],
  templateUrl: './third.component.html',
  styleUrl: './third.component.css'
})
export class ThirdComponent
 {
   constructor (private routerobj :Router )
   {  }  
   
   firstCompo()
   {
   this.routerobj.navigateByUrl('/firstcompo');
   }
   
   secondOpen()
   {
   this.routerobj.navigateByUrl('/secondcompo');
   }

}
