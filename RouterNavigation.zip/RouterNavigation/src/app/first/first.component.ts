import { Component } from '@angular/core';
import { SecondComponent } from '../second/second.component';
import { Router } from '@angular/router';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-first',
  standalone: true,
  imports: [SecondComponent,RouterLink],
  templateUrl: './first.component.html',
  styleUrl: './first.component.css'
})
export class FirstComponent
 {
  constructor (private router : Router)
  { }
  
  secondPrint()
  {
  this.router.navigateByUrl('/secondcompo');
  }
}
