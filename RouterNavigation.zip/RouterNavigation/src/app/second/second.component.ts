import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FirstComponent } from '../first/first.component';
import { ThirdComponent } from '../third/third.component';


@Component({
  selector: 'app-second',
  standalone: true,
  imports: [FirstComponent,ThirdComponent],
  templateUrl: './second.component.html',
  styleUrl: './second.component.css'
})
export class SecondComponent 
{
  constructor (private  routerobj : Router)
  { }

  firstfun()
  {
    this.routerobj.navigateByUrl('/firstcompo');
  }

  thirdfun()
  {
    this.routerobj.navigateByUrl('/thirdcompo');
  }


}
